ls ~/.cache/torch_extensions/py310_cu113/upfirdn2d
ls ~/.cache/torch_extensions/py310_cu113/fused/
rm -f ~/.cache/torch_extensions/py310_cu113/upfirdn2d/lock
rm -f ~/.cache/torch_extensions/py310_cu113/fused/lock